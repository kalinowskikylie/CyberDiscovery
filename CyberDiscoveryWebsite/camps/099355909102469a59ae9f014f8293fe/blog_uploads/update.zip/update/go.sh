#!/bin/bash

if [ `whoami` != "root" ]; then
	echo "You must be root.  Use "sudo" first."
	exit
fi

cp ./000*.cap /opt/CDGUI
cp ./CDGUI.jar /opt/CDGUI
cp ./cdgui.sh.new /opt/CDGUI
cp makeitwork.sh /opt/CDGUI
cp sniff.py /opt/CDGUI
cp *words.txt /home/cyber/Desktop/Presentations/Thursday/Wireless

echo Done.
