#!/bin/bash

if [ `whoami` != "root" ]; then
	echo "You must be root.  Use "sudo" first.
	exit
fi

mv /opt/CDGUI/cdgui.sh /opt/CDGUI/cdgui.sh.old
mv /opt/CDGUI/cdgui.sh.new /opt/CDGUI/cdgui.sh
